# Kavitha K — Personal Portfolio

A responsive, professional portfolio built with plain HTML, CSS, and JavaScript — no frameworks, no build step.

## Important — this is not live yet

I don't have access to your GitHub account, so I can't push or deploy anything on your behalf. The steps below are the **shortest possible path** to get this live at your exact target URL: `https://kavitha22-jap.github.io/`

## The one rule that matters

To get `https://kavitha22-jap.github.io/` (no extra path after it), your repository must be named **exactly**:

```
kavitha22-jap.github.io
```

This is a special "user site" repo name GitHub recognizes — it publishes automatically at the root URL with no extra Pages configuration needed. Any other repo name (e.g. `portfolio`) will publish at `https://kavitha22-jap.github.io/portfolio/` instead.

## Steps to go live (~3 minutes)

1. Go to [github.com/new](https://github.com/new) while logged in as `kavitha22-jap`.
2. Repository name: `kavitha22-jap.github.io` (exactly this, all lowercase).
3. Set it to **Public**. Do not add a README, .gitignore, or license (you already have these files).
4. Click **Create repository**.
5. Open a terminal in this project folder and run:
   ```bash
   git init
   git add .
   git commit -m "Initial portfolio commit"
   git branch -M main
   git remote add origin https://github.com/kavitha22-jap/kavitha22-jap.github.io.git
   git push -u origin main
   ```
6. Wait 1–2 minutes for GitHub to build the page.
7. Visit **https://kavitha22-jap.github.io/** — it should now be live.

If it doesn't load right away, check **Settings → Pages** in the repo — it should show "Your site is live at https://kavitha22-jap.github.io/". If Source isn't set, choose **Deploy from a branch → main → / (root)** and save.

## Files in this project

```
kavitha22-jap.github.io/
├── index.html   — page structure and content
├── style.css    — dark theme styling, layout, responsiveness
├── script.js    — mobile nav toggle + auto-updating footer year
└── README.md    — this file
```

## Replacing placeholders later

1. **Project GitHub link** — in `index.html`, search for `Replace this href`. Once you create a repo for the Advertisement Fraud Detection project, put its URL there instead of your profile link.
2. **Project technology stack** — the line `Full technology stack, dataset, and implementation details to be added here once finalized.` should be replaced with the real tools/libraries once confirmed (e.g. "Built using Python and Scikit-learn.").
3. **Certifications** — replace the `placeholder-card` block under `id="certifications"` with real certification cards once you have them (copy the `.skill-card` styling as a pattern).

## Making future edits live

Any time you edit these files and want the live site updated:
```bash
git add .
git commit -m "Update portfolio"
git push
```
GitHub Pages rebuilds automatically within a minute or two.
